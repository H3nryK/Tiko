document.addEventListener('DOMContentLoaded', () => {
    const preloader = document.getElementById('preloader');
    
    window.addEventListener('load', () => {
        preloader.style.display = 'none';
    });
});